package com.example.pulsar;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import org.apache.pulsar.client.api.PulsarClient;
import org.apache.pulsar.client.api.Consumer;

/**
 * Unit test for simple Consumer.
 */
public class MyPulsarConsumerTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
