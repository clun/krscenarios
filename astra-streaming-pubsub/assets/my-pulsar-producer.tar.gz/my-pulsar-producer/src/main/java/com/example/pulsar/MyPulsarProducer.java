package com.example.pulsar;

import java.util.Random;
import org.apache.pulsar.client.api.AuthenticationFactory;
import org.apache.pulsar.client.api.Producer;
import org.apache.pulsar.client.api.PulsarClient;
import org.apache.pulsar.client.api.PulsarClientException;
import org.apache.pulsar.client.api.Schema;

/**
 * Apache Pulsar Producer Example
 *
 */
public class MyPulsarProducer
{
    public static void main( String[] args ) throws PulsarClientException, java.lang.InterruptedException
    {

//TODO-create-PulsarClient

//TODO-create-Producer

//TODO-send

//TODO-close

    }
}
