package com.example.pulsar;


public class Measurement
{
  public String sensor;
  public long timestamp;
  public int value;
}
