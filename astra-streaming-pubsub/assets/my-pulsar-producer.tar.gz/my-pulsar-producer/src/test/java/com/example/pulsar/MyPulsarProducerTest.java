package com.example.pulsar;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import org.apache.pulsar.client.api.PulsarClient;
import org.apache.pulsar.client.api.Producer;

/**
 * Unit test for simple Producer.
 */
public class MyPulsarProducerTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
