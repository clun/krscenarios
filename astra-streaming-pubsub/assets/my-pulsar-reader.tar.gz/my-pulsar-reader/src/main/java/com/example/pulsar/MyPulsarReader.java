package com.example.pulsar;

import org.apache.pulsar.client.api.AuthenticationFactory;
import org.apache.pulsar.client.api.Message;
import org.apache.pulsar.client.api.MessageId;
import org.apache.pulsar.client.api.PulsarClient;
import org.apache.pulsar.client.api.PulsarClientException;
import org.apache.pulsar.client.api.Reader;
import org.apache.pulsar.client.api.Schema;

/**
 * Apache Pulsar Reader Example
 *
 */
public class MyPulsarReader
{
    public static void main( String[] args ) throws PulsarClientException, java.io.IOException
    {

//TODO-create-PulsarClient

//TODO-create-Reader

//TODO-read

//TODO-close

    }
}
