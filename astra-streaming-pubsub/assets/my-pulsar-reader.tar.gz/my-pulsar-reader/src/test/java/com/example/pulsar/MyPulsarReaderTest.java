package com.example.pulsar;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import org.apache.pulsar.client.api.PulsarClient;
import org.apache.pulsar.client.api.Reader;

/**
 * Unit test for simple Consumer.
 */
public class MyPulsarReaderTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
